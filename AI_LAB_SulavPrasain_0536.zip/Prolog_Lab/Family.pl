parent(abraham,homer).
parent(mona,homer).
parent(clancy,marge).
parent(jackie, marge).
parent(jackie,selma).
parent(jackie,patty).
parent(homer,bart).
parent(homer,lisa).
parent(marge,bart).
parent(marge,lisa).
parent(sudhan,sulav).
parent(suman,sulav).
parent(sudhan,mandeera).
parent(suman,mandeera).
male(sulav).
male(sudhan).
male(abraham).
male(homer).
male(jackie).
male(bart).
female(suman).
female(mandeera).
female(clancy).
female(marge).
female(selma).
female(patty).
female(lisa).
female(mona).
female(maggie).
female(selma).
female(ling).

mother(X,Y):-parent(X,Y),female(X).
father(X,Y):-parent(X,Y),male(X).
grandfather(X,Y):-parent(X,Z),parent(Z,Y),male(X).
grandmother(X,Y):-parent(X,Z),parent(Z,Y),female(X).
sister(X,Y):-female(X),parent(Z,Y),parent(Z,X),(X\=Y).
brother(X,Y):-male(X),parent(Z,Y),parent(Z,X),(X\=Y).
aunt(X,Y):-parent(Z,Y),sister(X,Z).
uncle(X,Y):-parent(Z,Y),brother(X,Z).
cousin(X,Y):-parent(Z,X),(uncle(Z,Y);aunt(Z,Y)).
sibling(X,Y):-(parent(Z,X),(uncle(Z,Y);aunt(Z,Y)));(parent(Z,Y),parent(Z,X)).

ancestor(X,Y):-parent(X,Y).
ancestor(X,Y):-parent(X,Z),ancestor(Z,Y).

predecessor(X,Y):-parent(X,Y).
predecessor(X,Y):-parent(X,S),predecessor(S,Y).

