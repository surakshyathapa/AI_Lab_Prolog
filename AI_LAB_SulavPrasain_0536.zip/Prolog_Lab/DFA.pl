t(0,a,1).
t(0,b,2).
t(1,a,1).
t(1,b,1).
t(2,a,2).
t(2,b,2).
checkinput(Start, []) :- Start is 1.
checkinput(Start, [H|T]) :- t(Start,H,Next), checkinput(Next, T).
