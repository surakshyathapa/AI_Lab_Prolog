eats(fred,pears).
eats(fred,t_bone_steak).
eats(fred,apples).

