parent( diwas, jeevan).
parent(govind, diwas).
parent(samir, govind).
parent(gopal,hari).
parent(hari,dhiraj).
parent(ramesh,rimal).
parent(arika,rimal).
parent(raman,kumar).
parent(kumar,hari).
parent(narayan, samir).
grandparent(A, B) :- parent(A, X), parent(X, B).
ancestor(A, B) :- parent(A, B).
ancestor(A, B) :- parent(A, X), ancestor(X, B).


