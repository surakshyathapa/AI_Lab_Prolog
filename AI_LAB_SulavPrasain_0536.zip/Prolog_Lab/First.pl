sky(blue).
likes(alice,bob).
likes(bob,carol).
likes(ram,sita).
greaterthan(5,3).
edge(a,b).
edge(a,f).
edge(f,g).
edge(f,e).
edge(f,c).
edge(b,c).
edge(g,c).
edge(c,e).
edge(c,d).
edge(e,d).
edge(X,Y):-tedge(X,Y).
tedge(Node1,Node2):- edge(Node1,SomeNode),edge(SomeNode,Node2).
path(Node1,Node2):- edge(Node1,Node2).
path(Node1,Node2):-edge(Node1,SomeNode),edge(SomeNode,Node2).

